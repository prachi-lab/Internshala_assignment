from django.db import models

class Product(models.Model):
    name= models.CharField(max_length=20)
    weight = models.CharField(max_length=20)
    price = models.CharField(max_length=20)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)



